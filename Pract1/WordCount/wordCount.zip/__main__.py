import re, json, pika
from cos_backend import COSBackend
from collections import Counter

def main(args):
	#get arguments
	s1 = json.dumps(args)
	args = json.loads(s1)
	res = args["res"]
	url = res["rabbitmq"]["url"]
	#configure COS library
	odb = COSBackend(res["ibm_cos"])
	#inicialize counter (we'll need it later)
	counts = Counter()
	
	#pika configuration
	params = pika.URLParameters(url)
	connection = pika.BlockingConnection(params)
	channel = connection.channel()
	channel.queue_declare(queue='WordCount')

	#get the part of the file that is needed in this function
	fileFromServer = odb.get_object(res["ibm_cos"]["bucket"], args["fileName"], extra_get_args={'Range':args["rang"]}).decode('UTF-8', errors='ignore')
	
	#Delete unwanted characters
	stringFiltered = re.sub('[^A-Za-z \n]+', '', fileFromServer)
	#Split the string
	stringSplitted = re.split("\ |\n", stringFiltered)
	#Delete "" in array
	stringSplitted = list(filter(None, stringSplitted))

	#convert array into count:
	#	{word1:numberWord1, word2:numberWord2...wordN:numberWordN}
	counts.update(word.strip('.,?!"\'').lower() for word in stringSplitted)
	#count to dict
	diccionary = dict(counts)
	#dict to json
	dumped_json_string = json.dumps(diccionary)
	#upload file with result:
	#	nameFile	->	book + numberFunction
	#	body		->	json(dict(count))
	odb.put_object(res["ibm_cos"]["bucket"], args["fileName"]+args["functionNumber"], dumped_json_string)
	#send a msg to reduce with the file name as body
	channel.basic_publish(exchange='', routing_key='WordCount', body=args["fileName"]+args["functionNumber"])
	#close the connection
	connection.close()
	return {}

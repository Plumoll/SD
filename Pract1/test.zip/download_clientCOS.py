
from cos_backend import COSBackend


if __name__ == "__main__":
	odb = COSBackend()

	fileFromServer = odb.get_object("magisd", "image123.jpeg")

	newFile = open("ImatgeNova.jpeg", "wb")

	newFile.write(fileFromServer)

	newFile.close()